import { useState, useEffect, useMemo } from "react";
import "./App.css";

/* ---------------- Utility Functions ---------------- */

const createId = () =>
  `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const formatDate = (timestamp) =>
  new Date(timestamp).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

const usePersistentState = (key, initialValue) => {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* Ignore storage errors */
    }
  }, [key, value]);

  return [value, setValue];
};

/* ---------------- Reusable UI Components ---------------- */

function SectionHeader({ icon, title, subtitle, count }) {
  return (
    <div className="section-head">
      <div className="section-title">
        <span className="section-icon">{icon}</span>
        <div>
          <h2>{title}</h2>
          <p>{subtitle}</p>
        </div>
      </div>
      <span className="count-pill">{count}</span>
    </div>
  );
}

function EmptyState({ icon, title, message }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{message}</p>
    </div>
  );
}

/* ---------------- To-Do Components ---------------- */

function TaskItem({ task, onToggle, onDelete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState(task.text);

  const saveEdit = () => {
    if (editedText.trim()) {
      onEdit(task.id, editedText.trim());
    }
    setIsEditing(false);
  };

  const isOverdue =
    task.dueDate && !task.completed && new Date(task.dueDate) < new Date();

  return (
    <li className={`task-card ${task.completed ? "completed" : ""}`}>
      <button
        className="check-btn"
        onClick={() => onToggle(task.id)}
        aria-label="Toggle task completion"
      >
        {task.completed ? "✓" : ""}
      </button>

      <div className="task-body">
        {isEditing ? (
          <input
            className="edit-input"
            value={editedText}
            onChange={(event) => setEditedText(event.target.value)}
            onKeyDown={(event) => event.key === "Enter" && saveEdit()}
            autoFocus
          />
        ) : (
          <>
            <p className="task-text">{task.text}</p>
            <div className="task-meta">
              <span className={`status ${task.completed ? "done" : "pending"}`}>
                {task.completed ? "Completed" : "Pending"}
              </span>
              {task.dueDate && (
                <span className={`due ${isOverdue ? "overdue" : ""}`}>
                  Due: {task.dueDate}
                </span>
              )}
            </div>
          </>
        )}
      </div>

      <div className="task-actions">
        {isEditing ? (
          <button className="icon-btn save" onClick={saveEdit}>
            💾
          </button>
        ) : (
          <button
            className="icon-btn"
            onClick={() => {
              setEditedText(task.text);
              setIsEditing(true);
            }}
          >
            ✏️
          </button>
        )}
        <button className="icon-btn delete" onClick={() => onDelete(task.id)}>
          🗑️
        </button>
      </div>
    </li>
  );
}

function TodoApp() {
  const [tasks, setTasks] = usePersistentState("nova-tasks", []);
  const [taskText, setTaskText] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [filter, setFilter] = useState("all");

  const addTask = (event) => {
    event.preventDefault();
    if (!taskText.trim()) return;

    const newTask = {
      id: createId(),
      text: taskText.trim(),
      completed: false,
      dueDate,
      createdAt: Date.now(),
    };

    setTasks((previous) => [newTask, ...previous]);
    setTaskText("");
    setDueDate("");
  };

  const toggleTask = (id) =>
    setTasks((previous) =>
      previous.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );

  const deleteTask = (id) =>
    setTasks((previous) => previous.filter((task) => task.id !== id));

  const editTask = (id, newText) =>
    setTasks((previous) =>
      previous.map((task) =>
        task.id === id ? { ...task, text: newText } : task
      )
    );

  const filteredTasks = useMemo(() => {
    if (filter === "completed") {
      return tasks.filter((task) => task.completed);
    }
    if (filter === "pending") {
      return tasks.filter((task) => !task.completed);
    }
    return tasks;
  }, [tasks, filter]);

  const completedCount = tasks.filter((task) => task.completed).length;

  return (
    <section className="panel todo-panel">
      <SectionHeader
        icon="✅"
        title="Task Flow"
        subtitle={`${completedCount} of ${tasks.length} tasks completed`}
        count={tasks.length}
      />

      <form className="task-form" onSubmit={addTask}>
        <input
          type="text"
          placeholder="What needs to be done today?"
          value={taskText}
          onChange={(event) => setTaskText(event.target.value)}
        />
        <input
          type="date"
          value={dueDate}
          onChange={(event) => setDueDate(event.target.value)}
        />
        <button type="submit">Add Task</button>
      </form>

      <div className="filter-row">
        {["all", "pending", "completed"].map((type) => (
          <button
            key={type}
            className={`filter-btn ${filter === type ? "active" : ""}`}
            onClick={() => setFilter(type)}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </button>
        ))}
      </div>

      {filteredTasks.length === 0 ? (
        <EmptyState
          icon="🗒️"
          title="No tasks here"
          message="Add your first task and start organizing your day."
        />
      ) : (
        <ul className="task-list">
          {filteredTasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onToggle={toggleTask}
              onDelete={deleteTask}
              onEdit={editTask}
            />
          ))}
        </ul>
      )}
    </section>
  );
}

/* ---------------- Notes Components ---------------- */

function NoteCard({ note, onDelete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [category, setCategory] = useState(note.category);

  const saveNote = () => {
    if (!title.trim() && !content.trim()) return;

    onEdit(note.id, {
      title: title.trim() || "Untitled Note",
      content: content.trim(),
      category: category.trim() || "General",
    });
    setIsEditing(false);
  };

  return (
    <article className={`note-card category-${note.category.toLowerCase()}`}>
      {isEditing ? (
        <div className="note-edit">
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Note title"
          />
          <input
            value={category}
            onChange={(event) => setCategory(event.target.value)}
            placeholder="Category"
          />
          <textarea
            value={content}
            onChange={(event) => setContent(event.target.value)}
            placeholder="Write your note..."
          />
          <div className="note-actions">
            <button className="primary-btn" onClick={saveNote}>
              Save
            </button>
            <button className="ghost-btn" onClick={() => setIsEditing(false)}>
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="note-top">
            <span className="note-category">{note.category}</span>
            <div>
              <button className="icon-btn" onClick={() => setIsEditing(true)}>
                ✏️
              </button>
              <button
                className="icon-btn delete"
                onClick={() => onDelete(note.id)}
              >
                🗑️
              </button>
            </div>
          </div>

          <h3>{note.title}</h3>
          <p>{note.content}</p>
          <span className="note-time">Updated {formatDate(note.updatedAt)}</span>
        </>
      )}
    </article>
  );
}

function NotesApp() {
  const [notes, setNotes] = usePersistentState("nova-notes", []);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const addNote = (event) => {
    event.preventDefault();
    if (!title.trim() && !content.trim()) return;

    const newNote = {
      id: createId(),
      title: title.trim() || "Untitled Note",
      content: content.trim(),
      category: category.trim() || "General",
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    setNotes((previous) => [newNote, ...previous]);
    setTitle("");
    setContent("");
    setCategory("");
  };

  const deleteNote = (id) =>
    setNotes((previous) => previous.filter((note) => note.id !== id));

  const editNote = (id, updatedData) =>
    setNotes((previous) =>
      previous.map((note) =>
        note.id === id
          ? { ...note, ...updatedData, updatedAt: Date.now() }
          : note
      )
    );

  const filteredNotes = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return notes.filter(
      (note) =>
        note.title.toLowerCase().includes(term) ||
        note.content.toLowerCase().includes(term) ||
        note.category.toLowerCase().includes(term)
    );
  }, [notes, searchTerm]);

  return (
    <section className="panel notes-panel">
      <SectionHeader
        icon="📝"
        title="Idea Vault"
        subtitle="Create, organize, and search your notes"
        count={notes.length}
      />

      <form className="note-form" onSubmit={addNote}>
        <input
          type="text"
          placeholder="Note title"
          value={title}
          onChange={(event) => setTitle(event.target.value)}
        />
        <input
          type="text"
          placeholder="Category, e.g. Project, Personal"
          value={category}
          onChange={(event) => setCategory(event.target.value)}
        />
        <textarea
          placeholder="Write your note..."
          value={content}
          onChange={(event) => setContent(event.target.value)}
        />
        <button type="submit">Create Note</button>
      </form>

      <input
        className="search-input"
        type="search"
        placeholder="🔍 Search notes by title, content, or category"
        value={searchTerm}
        onChange={(event) => setSearchTerm(event.target.value)}
      />

      {filteredNotes.length === 0 ? (
        <EmptyState
          icon="💡"
          title="No notes found"
          message="Create a note or try a different search term."
        />
      ) : (
        <div className="notes-grid">
          {filteredNotes.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onDelete={deleteNote}
              onEdit={editNote}
            />
          ))}
        </div>
      )}
    </section>
  );
}

/* ---------------- Main App ---------------- */

export default function App() {
  const [activeTab, setActiveTab] = useState("todo");

  return (
    <div className="app-shell">
      <div className="glow glow-one" />
      <div className="glow glow-two" />

      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">N</div>
          <div>
            <h1>Keerthi Apps</h1>
            <p>Tasks & Notes Apps</p>
          </div>
        </div>

        <nav className="tab-nav">
          <button
            className={activeTab === "todo" ? "tab active" : "tab"}
            onClick={() => setActiveTab("todo")}
          >
            ✅ To-Do
          </button>
          <button
            className={activeTab === "notes" ? "tab active" : "tab"}
            onClick={() => setActiveTab("notes")}
          >
            📝 Notes
          </button>
        </nav>
      </header>

      <main>{activeTab === "todo" ? <TodoApp /> : <NotesApp />}</main>

      <footer className="footer">
        Built with React.js • Data saved in your browser using LocalStorage
      </footer>
    </div>
  );
}